/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.Statement;

/**
 *
 * @author gokul
 */
public class Tables {

    public static void main(String[] args) {
        try {
            Connection con = ConnectionProvider.getCon();
            Statement st = con.createStatement();
            // st.executeUpdate("create table appuser(appuser_pk int AUTO_INCREMENT primary key,userRole varchar(200),name varchar(200),dob varchar(50),mobileNumber varchar(50),email varchar(50),username varchar(200),password varchar(200),address varchar(200))");
            // st.executeUpdate("insert into appuser values('1','Admin','Admin','12-12-1999','9898989898','admin@gmail.com','admin','admin','india')");
            //st.executeUpdate("create table medicine(uniqueID varchar(200) primary key,name varchar(200),companyName varchar(200),quantity int,price int)");
          // st.executeUpdate("create table bills(billId varchar(200),billDate varchar(50),totalPaid int,generatedBy varchar(50)),");
           // st.executeUpdate("delete from bill where generatedBy=null");
         // st.executeUpdate("alter table billdetails add constraint fk_meddet foreign key(bid) references bill(billID)") ;
           //st.executeUpdate("create table billdetails (medicineid varchar(200),bid varchar(200))");
            //st.executeUpdate("insert into billdetails values('101','Bill-175507699432000')");
            st.executeUpdate("alter table billdetails rename column medicineid to medId");
           //JOptionPane.showMessageDialog(null, "Table create successfully");
            JOptionPane.showMessageDialog(null, "Table update successfully");



        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
